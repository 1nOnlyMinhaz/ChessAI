
class Piece:
    def __init__(self, board, name, color, position):
        self.board = board
        self.color = color
        self.name = name
        self.pos = position
        board.pieces[self.pos[0]][self.pos[1]] = self
        self.image = board.createImage(f"./Pieces/{color}/{name}.png", position)
        self.board.canvas.tag_bind(self.image, "<B1-Motion>", self.movePiece)
        self.board.canvas.tag_bind(self.image, "<ButtonPress>", self.startMovement)
        self.board.canvas.tag_bind(self.image, "<ButtonRelease>", self.stopMovement)

    def movePiece(self, event):
        MAXPIECEX = self.board.canvas.winfo_reqwidth()-self.board.size
        MAXPIECEY = self.board.canvas.winfo_reqheight()-self.board.size
        # Get the current position of the mouse
        self.pos[0] = event.x - (self.board.size / 2) if event.x > (self.board.size / 2) else 0
        self.pos[1] = event.y - (self.board.size / 2) if event.y > (self.board.size / 2) else 0
        self.pos[0] = MAXPIECEX if self.pos[0] > MAXPIECEX else self.pos[0]
        self.pos[1] = MAXPIECEY if self.pos[1] > MAXPIECEY else self.pos[1]
        # Move the image to the new position
        self.board.canvas.coords(self.image, self.pos[0], self.pos[1])
        self.board.canvas.lift(self.image)

    def startMovement(self, event):
        pass

    def stopMovement(self, event):
        self.pos[0] = event.x//self.board.size
        self.pos[1] = event.y//self.board.size
        if self.pos[0] > self.board.rows-1:
            self.pos[0] = self.board.rows-1
        if self.pos[1] > self.board.cols-1:
            self.pos[1] = self.board.cols-1
        if self.pos[0] < 0:
            self.pos[0] = 0
        if self.pos[1] < 0:
            self.pos[1] = 0
        self.board.pieces[self.pos[0]][self.pos[1]] = self
        self.board.canvas.coords(self.image, self.pos[0]*self.board.size, self.pos[1]*self.board.size)

class Pawn(Piece):
    def __init__(self, board, color, position):
        super().__init__(board, "Pawn", color, position)
        self.board = board
        self.color = color
        self.pos = position


class Rook(Piece):
    def __init__(self, board, color, position):
        super().__init__(board, "Rook", color, position)
        self.board = board
        self.color = color
        self.pos = position

class Bishop(Piece):
    def __init__(self, board, color, position):
        super().__init__(board, "Bishop", color, position)
        self.board = board
        self.color = color
        self.pos = position

class Knight(Piece):
    def __init__(self, board, color, position):
        super().__init__(board, "Knight", color, position)
        self.board = board
        self.color = color
        self.pos = position

class Queen(Piece):
    def __init__(self, board, color, position):
        super().__init__(board, "Queen", color, position)
        self.board = board
        self.color = color
        self.pos = position

class King(Piece):
    def __init__(self, board, color, position):
        super().__init__(board, "King", color, position)
        self.board = board
        self.color = color
        self.pos = position


