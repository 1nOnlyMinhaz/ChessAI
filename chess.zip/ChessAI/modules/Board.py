import modules.Constants as Constants
from modules.Constants import SQSIZE
from modules.Pieces import *
from PIL import Image, ImageTk
import tkinter as tk

class Board:
    def __init__(self, canvas, rows, cols):
        self.canvas = canvas
        self.rows = rows
        self.cols = cols
        self.size = SQSIZE
        self.squares = []
        self.pieces = [[0 for i in range(self.cols)] for i in range(self.rows)]
        self.photoImages = []
        self.images = []
        self.imageObjects = []
        self.CurrentColour = "Black"

        for row in range(self.rows):
            for col in range(self.cols):
                x1 = col * Constants.SQSIZE
                y1 = row * Constants.SQSIZE
                x2 = x1 + Constants.SQSIZE
                y2 = y1 + Constants.SQSIZE
                if (row + col) % 2 == 0:
                    self.squares.append(canvas.create_rectangle(x1, y1, x2, y2, fill="#C74C51", outline="#F6D686"))
                else:
                    self.squares.append(canvas.create_rectangle(x1, y1, x2, y2, fill="#303030", outline="#F6D686"))


        # Load all pieces

        for i in range(8):
            Pawn(self, "Black", [i, 1])
        for i in range(8):
            Pawn(self, "White", [i, 6])

    def Resize(self, newSize):
        size_ratio = newSize / self.size
        for row in range(self.rows):
            y1 = row * newSize
            y2 = y1 + newSize
            for col in range(self.cols):
                x1 = col * newSize
                x2 = x1 + newSize
                self.canvas.coords(self.squares[(row*self.rows)+col], x1, y1, x2, y2)
        for i in range(len(self.images)):
            image = self.images[i]
            image = image.resize((newSize, newSize), Image.Resampling.LANCZOS)
            self.photoImages[i] = ImageTk.PhotoImage(image)
            self.canvas.itemconfig(self.imageObjects[i], image=self.photoImages[i])
            x, y = self.canvas.coords(self.imageObjects[i])
            self.canvas.coords(self.imageObjects[i], x*size_ratio, y*size_ratio)
        self.size = newSize


    def createImage(self, fileName: str, position):
        """
        :param fileName: The name of the image file
        :param position: The position of the image on the board
        :return: 
        """
        img = Image.open(fileName)
        img = img.convert("RGBA")
        self.images.append(img)
        self.photoImages.append(ImageTk.PhotoImage(img))
        imageObject = self.canvas.create_image(position[0]*self.size, position[1]*self.size, image=self.photoImages[-1], anchor="nw")
        self.imageObjects.append(imageObject)
        return imageObject
