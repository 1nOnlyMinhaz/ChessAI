import tkinter
import tkinter as tk
from tkinter import ttk, PhotoImage
from PIL import Image, ImageTk
import modules.Constants as Constants
from modules.Board import Board


class Window(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('ChessAI')
        self.geometry(f'{Constants.WIDTH}x{Constants.HEIGHT}')
        self.iconbitmap("icon.ico")
        self.minsize(Constants.WIDTH, Constants.HEIGHT)

        canvas = tkinter.Canvas(self)
        canvas.pack()

        self.canvas = canvas
        self.bind("<Configure>", self.onResize)
        self.board = Board(self.canvas, Constants.ROWS, Constants.COLS)


    def onResize(self, event):
        size = min(event.width, event.height)
        if size == self.canvas.winfo_width() or size == self.canvas.winfo_height():
            return
        self.canvas.config(width=size, height=size)
        self.board.Resize(size//Constants.ROWS)


Window().mainloop()